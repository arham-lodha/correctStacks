import java.io.File;
import java.util.Scanner;

public class RPNCalculator {

    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(new File("input.txt"));

        ArrayStack numStack = new ArrayStack();

        int numInput = Integer.parseInt(input.nextLine());

        for (int i = 0; i < numInput; i++) {
            String[] arrInput = input.nextLine().split(" ");
            for (int j = 0; j < arrInput.length; j++) {

                if(!arrInput[j].equals("+") || !arrInput[j].equals("*")
                || !arrInput[j].equals("-") || !arrInput.equals("/")){
                    numStack.push(Double.parseDouble(arrInput[j]));
                }
                else {
                    if(numStack.size() != 2) {
                        System.out.println("Invalid");
                        break;
                    }

                    double a = numStack.pop();
                    double b = numStack.pop();

                    switch (arrInput[j]){
                        case "+":
                            numStack.push(b + a);
                            break;
                        case "-":
                            numStack.push(b - a);
                            break;
                        case "/":
                            numStack.push(b / a);
                            break;
                        case "*":
                            numStack.push(b * a);
                    }

                    if(numStack.size() != 2) {
                        System.out.println("Invalid");
                        break;
                    }
                }

            }
            System.out.println(numStack.pop());

        }

        input.close();
    }

}
