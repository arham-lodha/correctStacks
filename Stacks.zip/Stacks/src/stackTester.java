public class stackTester {

    public static void main(String[] args) {

        ArrayStack stack1 = new ArrayStack();
        stack1.push(1.1);
        stack1.push(1.3);
        stack1.push(1.3);
        System.out.println(stack1.ArrayToString());
        System.out.println(stack1.toString());
        System.out.println(stack1.pop());
        stack1.push(1.4);
        System.out.println(stack1);
        System.out.println(stack1.peek());
        System.out.println(stack1.isFull());
        stack1.clear();
        stack1.push(0.5);
        System.out.println(stack1);
        System.out.println(stack1.ArrayToString());


    }

}
