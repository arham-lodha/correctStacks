class ArrayStack implements IStack {

    private int top;
    private double[] arr;
    private static final int DEFAULT_SIZE = 10;

    public ArrayStack(int size) {
        arr = new double[size];
        top = -1;
    }

    public ArrayStack(){
        arr = new double[DEFAULT_SIZE];
        top = -1;
    }

    @Override
    public void push(double value){
        if(isFull()){
            System.out.println("0");
            return;
        }
        top++;
        arr[top] = value;
    }

    @Override
    public double pop() {
        if(isEmpty()){
            return 0;
        }
        double value = arr[top];
        top--;
        return value;
    }

    @Override
    public double peek() {
        return arr[top];
    }

    @Override
    public int size() {
        return top + 1;
    }

    @Override
    public boolean isEmpty() {
        return top < 0;
    }

    @Override
    public boolean isFull() {
        return top >= arr.length;
    }

    @Override
    public void clear() {
        top = -1;
    }

    @Override
    public String toString() {
        String stack = "";
        for(int i = 0; i <= top; i++){
            stack += arr[i] + " ";
        }
        return stack;
    }

    @Override
    public String ArrayToString() {
        String stack = "";
        for(int i = 0; i < arr.length; i++){
            stack += arr[i] + " ";
        }
        return stack;
    }
}
